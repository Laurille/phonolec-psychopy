#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.82.01), Sam 19 mar 18:58:03 2016
If you publish work using this script please cite the relevant PsychoPy publications
  Peirce, JW (2007) PsychoPy - Psychophysics software in Python. Journal of Neuroscience Methods, 162(1-2), 8-13.
  Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy. Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import division  # so that 1/3=0.333 instead of 1/3=0
from psychopy import visual, core, data, event, logging, sound, gui
from psychopy.constants import *  # things like STARTED, FINISHED
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import sin, cos, tan, log, log10, pi, average, sqrt, std, deg2rad, rad2deg, linspace, asarray
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'elision_phonemique'  # from the Builder filename that created this script
expInfo = {u'age': u'', u'session': u'001', u'patient': u'', u'evaluateur': u''}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False: core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + 'data/%s_%s_%s_%s' %(expInfo['evaluateur'], expInfo['patient'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=u'/Users/laurencemourier/Google Drive/test_PsychoPy/ex2/elision_phonemique.psyexp',
    savePickle=True, saveWideText=False,
    dataFileName=filename)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(size=(1440, 900), fullscr=True, screen=0, allowGUI=True, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True,
    )
# store frame rate of monitor if we can measure it successfully
expInfo['frameRate']=win.getActualFrameRate()
if expInfo['frameRate']!=None:
    frameDur = 1.0/round(expInfo['frameRate'])
else:
    frameDur = 1.0/60.0 # couldn't get a reliable measure so guess

# Initialize components for Routine "titre"
titreClock = core.Clock()
txt_titre = visual.TextStim(win=win, ori=0, name='txt_titre',
    text='EXERCICE 2',    font='Arial',
    pos=[0, 0], height=0.25, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "consigne"
consigneClock = core.Clock()
txt_cons1 = visual.TextStim(win=win, ori=0, name='txt_cons1',
    text=u"Vous allez voir une image qui repr\xe9sente un mot, et une lettre qui repr\xe9sente un son.\n\nQuand vous enlevez le son au mot, que reste-t-il ?\n\nPrononcez ce qu'il reste, m\xeame si \xe7a ne veut rien dire.",    font='Arial',
    pos=[0, 0], height=0.125, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "annonce_ex"
annonce_exClock = core.Clock()
txt_ann_ex = visual.TextStim(win=win, ori=0, name='txt_ann_ex',
    text=u"Vous allez d'abord vous entrainer.\n\nEtes-vous pr\xeat ?",    font='Arial',
    pos=[0, 0], height=0.125, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "evaluation"
evaluationClock = core.Clock()
img_complet = visual.ImageStim(win=win, name='img_complet',
    image='sin', mask=None,
    ori=0, pos=[-0.55, 0], size=[0.8, 0.8],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
txt_elision = visual.TextStim(win=win, ori=0, name='txt_elision',
    text='default text',    font='Arial',
    pos=[0.2, 0], height=0.3, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-2.0)
minus = visual.TextStim(win=win, ori=0, name='minus',
    text='-',    font='Arial',
    pos=[-0.05, 0], height=0.3, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-3.0)
equal = visual.TextStim(win=win, ori=0, name='equal',
    text='=  ?',    font='Arial',
    pos=[0.6, 0], height=0.3, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-4.0)

# Initialize components for Routine "solution"
solutionClock = core.Clock()
txt_sol = visual.TextStim(win=win, ori=0, name='txt_sol',
    text='default text',    font='Arial',
    pos=[0, -0.2], height=0.125, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)
img_1 = visual.ImageStim(win=win, name='img_1',
    image='sin', mask=None,
    ori=0, pos=[-0.3, 0.25], size=[0.4, 0.54],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
txt_el_sol = visual.TextStim(win=win, ori=0, name='txt_el_sol',
    text='default text',    font='Arial',
    pos=[0.2, 0.25], height=0.125, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-3.0)
minus2 = visual.TextStim(win=win, ori=0, name='minus2',
    text='-',    font='Arial',
    pos=[0, 0.25], height=0.1, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-4.0)

# Initialize components for Routine "evaluation"
evaluationClock = core.Clock()
img_complet = visual.ImageStim(win=win, name='img_complet',
    image='sin', mask=None,
    ori=0, pos=[-0.55, 0], size=[0.8, 0.8],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
txt_elision = visual.TextStim(win=win, ori=0, name='txt_elision',
    text='default text',    font='Arial',
    pos=[0.2, 0], height=0.3, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-2.0)
minus = visual.TextStim(win=win, ori=0, name='minus',
    text='-',    font='Arial',
    pos=[-0.05, 0], height=0.3, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-3.0)
equal = visual.TextStim(win=win, ori=0, name='equal',
    text='=  ?',    font='Arial',
    pos=[0.6, 0], height=0.3, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-4.0)

# Initialize components for Routine "annonce_exercice"
annonce_exerciceClock = core.Clock()
txt_exer = visual.TextStim(win=win, ori=0, name='txt_exer',
    text=u"L'exercice va commencer.\n\nDonnez votre r\xe9ponse \xe0 voix haute, le plus rapidement possible.\n\nEtes-vous pr\xeat ?",    font='Arial',
    pos=[0, 0], height=0.125, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "evaluation"
evaluationClock = core.Clock()
img_complet = visual.ImageStim(win=win, name='img_complet',
    image='sin', mask=None,
    ori=0, pos=[-0.55, 0], size=[0.8, 0.8],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
txt_elision = visual.TextStim(win=win, ori=0, name='txt_elision',
    text='default text',    font='Arial',
    pos=[0.2, 0], height=0.3, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-2.0)
minus = visual.TextStim(win=win, ori=0, name='minus',
    text='-',    font='Arial',
    pos=[-0.05, 0], height=0.3, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-3.0)
equal = visual.TextStim(win=win, ori=0, name='equal',
    text='=  ?',    font='Arial',
    pos=[0.6, 0], height=0.3, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-4.0)

# Initialize components for Routine "fin"
finClock = core.Clock()
txt_fin = visual.TextStim(win=win, ori=0, name='txt_fin',
    text=u'Merci, ce deuxi\xe8me exercice est termin\xe9.',    font='Arial',
    pos=[0, 0], height=0.2, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

#------Prepare to start Routine "titre"-------
t = 0
titreClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_5 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_5.status = NOT_STARTED
# keep track of which components have finished
titreComponents = []
titreComponents.append(txt_titre)
titreComponents.append(key_resp_5)
for thisComponent in titreComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "titre"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = titreClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_titre* updates
    if t >= 0.0 and txt_titre.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_titre.tStart = t  # underestimates by a little under one frame
        txt_titre.frameNStart = frameN  # exact frame index
        txt_titre.setAutoDraw(True)
    
    # *key_resp_5* updates
    if t >= 0.0 and key_resp_5.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_5.tStart = t  # underestimates by a little under one frame
        key_resp_5.frameNStart = frameN  # exact frame index
        key_resp_5.status = STARTED
        # keyboard checking is just starting
        key_resp_5.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_5.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_5.keys = theseKeys[-1]  # just the last key pressed
            key_resp_5.rt = key_resp_5.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in titreComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "titre"-------
for thisComponent in titreComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_5.keys in ['', [], None]:  # No response was made
   key_resp_5.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_5.keys',key_resp_5.keys)
if key_resp_5.keys != None:  # we had a response
    thisExp.addData('key_resp_5.rt', key_resp_5.rt)
thisExp.nextEntry()
# the Routine "titre" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

#------Prepare to start Routine "consigne"-------
t = 0
consigneClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_2 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_2.status = NOT_STARTED
# keep track of which components have finished
consigneComponents = []
consigneComponents.append(txt_cons1)
consigneComponents.append(key_resp_2)
for thisComponent in consigneComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "consigne"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = consigneClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_cons1* updates
    if t >= 0.0 and txt_cons1.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_cons1.tStart = t  # underestimates by a little under one frame
        txt_cons1.frameNStart = frameN  # exact frame index
        txt_cons1.setAutoDraw(True)
    
    # *key_resp_2* updates
    if t >= 0.0 and key_resp_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_2.tStart = t  # underestimates by a little under one frame
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_resp_2.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in consigneComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "consigne"-------
for thisComponent in consigneComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "consigne" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

#------Prepare to start Routine "annonce_ex"-------
t = 0
annonce_exClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_8 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_8.status = NOT_STARTED
# keep track of which components have finished
annonce_exComponents = []
annonce_exComponents.append(txt_ann_ex)
annonce_exComponents.append(key_resp_8)
for thisComponent in annonce_exComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "annonce_ex"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = annonce_exClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_ann_ex* updates
    if t >= 0.0 and txt_ann_ex.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_ann_ex.tStart = t  # underestimates by a little under one frame
        txt_ann_ex.frameNStart = frameN  # exact frame index
        txt_ann_ex.setAutoDraw(True)
    
    # *key_resp_8* updates
    if t >= 0.0 and key_resp_8.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_8.tStart = t  # underestimates by a little under one frame
        key_resp_8.frameNStart = frameN  # exact frame index
        key_resp_8.status = STARTED
        # keyboard checking is just starting
        key_resp_8.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_8.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_8.keys = theseKeys[-1]  # just the last key pressed
            key_resp_8.rt = key_resp_8.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in annonce_exComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "annonce_ex"-------
for thisComponent in annonce_exComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_8.keys in ['', [], None]:  # No response was made
   key_resp_8.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_8.keys',key_resp_8.keys)
if key_resp_8.keys != None:  # we had a response
    thisExp.addData('key_resp_8.rt', key_resp_8.rt)
thisExp.nextEntry()
# the Routine "annonce_ex" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
exemples_el_phon = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=u'/Users/laurencemourier/Google Drive/test_PsychoPy/ex2/elision_phonemique.psyexp',
    trialList=data.importConditions('elision_phonemique.xlsx', selection='0,1,2'),
    seed=None, name='exemples_el_phon')
thisExp.addLoop(exemples_el_phon)  # add the loop to the experiment
thisExemples_el_phon = exemples_el_phon.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisExemples_el_phon.rgb)
if thisExemples_el_phon != None:
    for paramName in thisExemples_el_phon.keys():
        exec(paramName + '= thisExemples_el_phon.' + paramName)

for thisExemples_el_phon in exemples_el_phon:
    currentLoop = exemples_el_phon
    # abbreviate parameter names if possible (e.g. rgb = thisExemples_el_phon.rgb)
    if thisExemples_el_phon != None:
        for paramName in thisExemples_el_phon.keys():
            exec(paramName + '= thisExemples_el_phon.' + paramName)
    
    #------Prepare to start Routine "evaluation"-------
    t = 0
    evaluationClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    img_complet.setImage(complet)
    touche_rep = event.BuilderKeyResponse()  # create an object of type KeyResponse
    touche_rep.status = NOT_STARTED
    txt_elision.setText(elision)
    # keep track of which components have finished
    evaluationComponents = []
    evaluationComponents.append(img_complet)
    evaluationComponents.append(touche_rep)
    evaluationComponents.append(txt_elision)
    evaluationComponents.append(minus)
    evaluationComponents.append(equal)
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "evaluation"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = evaluationClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *img_complet* updates
        if t >= 0.0 and img_complet.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_complet.tStart = t  # underestimates by a little under one frame
            img_complet.frameNStart = frameN  # exact frame index
            img_complet.setAutoDraw(True)
        
        # *touche_rep* updates
        if t >= 0.0 and touche_rep.status == NOT_STARTED:
            # keep track of start time/frame for later
            touche_rep.tStart = t  # underestimates by a little under one frame
            touche_rep.frameNStart = frameN  # exact frame index
            touche_rep.status = STARTED
            # keyboard checking is just starting
            touche_rep.clock.reset()  # now t=0
            event.clearEvents(eventType='keyboard')
        if touche_rep.status == STARTED:
            theseKeys = event.getKeys(keyList=['o', 'n', 'a'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                touche_rep.keys = theseKeys[-1]  # just the last key pressed
                touche_rep.rt = touche_rep.clock.getTime()
                # was this 'correct'?
                if (touche_rep.keys == str("'o'")) or (touche_rep.keys == "'o'"):
                    touche_rep.corr = 1
                else:
                    touche_rep.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *txt_elision* updates
        if t >= 0.0 and txt_elision.status == NOT_STARTED:
            # keep track of start time/frame for later
            txt_elision.tStart = t  # underestimates by a little under one frame
            txt_elision.frameNStart = frameN  # exact frame index
            txt_elision.setAutoDraw(True)
        
        # *minus* updates
        if t >= 0.0 and minus.status == NOT_STARTED:
            # keep track of start time/frame for later
            minus.tStart = t  # underestimates by a little under one frame
            minus.frameNStart = frameN  # exact frame index
            minus.setAutoDraw(True)
        
        # *equal* updates
        if t >= 0.0 and equal.status == NOT_STARTED:
            # keep track of start time/frame for later
            equal.tStart = t  # underestimates by a little under one frame
            equal.frameNStart = frameN  # exact frame index
            equal.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in evaluationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "evaluation"-------
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if touche_rep.keys in ['', [], None]:  # No response was made
       touche_rep.keys=None
       # was no response the correct answer?!
       if str("'o'").lower() == 'none': touche_rep.corr = 1  # correct non-response
       else: touche_rep.corr = 0  # failed to respond (incorrectly)
    # store data for exemples_el_phon (TrialHandler)
    exemples_el_phon.addData('touche_rep.keys',touche_rep.keys)
    exemples_el_phon.addData('touche_rep.corr', touche_rep.corr)
    if touche_rep.keys != None:  # we had a response
        exemples_el_phon.addData('touche_rep.rt', touche_rep.rt)
    # the Routine "evaluation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    #------Prepare to start Routine "solution"-------
    t = 0
    solutionClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    txt_sol.setText(solution)
    key_resp_3 = event.BuilderKeyResponse()  # create an object of type KeyResponse
    key_resp_3.status = NOT_STARTED
    img_1.setImage(complet)
    txt_el_sol.setText(elision)
    # keep track of which components have finished
    solutionComponents = []
    solutionComponents.append(txt_sol)
    solutionComponents.append(key_resp_3)
    solutionComponents.append(img_1)
    solutionComponents.append(txt_el_sol)
    solutionComponents.append(minus2)
    for thisComponent in solutionComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "solution"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = solutionClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *txt_sol* updates
        if t >= 0.0 and txt_sol.status == NOT_STARTED:
            # keep track of start time/frame for later
            txt_sol.tStart = t  # underestimates by a little under one frame
            txt_sol.frameNStart = frameN  # exact frame index
            txt_sol.setAutoDraw(True)
        
        # *key_resp_3* updates
        if t >= 0.0 and key_resp_3.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_3.tStart = t  # underestimates by a little under one frame
            key_resp_3.frameNStart = frameN  # exact frame index
            key_resp_3.status = STARTED
            # keyboard checking is just starting
            event.clearEvents(eventType='keyboard')
        if key_resp_3.status == STARTED:
            theseKeys = event.getKeys(keyList=['right'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                # a response ends the routine
                continueRoutine = False
        
        # *img_1* updates
        if t >= 0.0 and img_1.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_1.tStart = t  # underestimates by a little under one frame
            img_1.frameNStart = frameN  # exact frame index
            img_1.setAutoDraw(True)
        
        # *txt_el_sol* updates
        if t >= 0.0 and txt_el_sol.status == NOT_STARTED:
            # keep track of start time/frame for later
            txt_el_sol.tStart = t  # underestimates by a little under one frame
            txt_el_sol.frameNStart = frameN  # exact frame index
            txt_el_sol.setAutoDraw(True)
        
        # *minus2* updates
        if t >= 0.0 and minus2.status == NOT_STARTED:
            # keep track of start time/frame for later
            minus2.tStart = t  # underestimates by a little under one frame
            minus2.frameNStart = frameN  # exact frame index
            minus2.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in solutionComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "solution"-------
    for thisComponent in solutionComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "solution" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
# completed 1 repeats of 'exemples_el_phon'


# set up handler to look after randomisation of conditions etc
exe_phon = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=u'/Users/laurencemourier/Google Drive/test_PsychoPy/ex2/elision_phonemique.psyexp',
    trialList=data.importConditions('elision_phonemique.xlsx', selection='3,4'),
    seed=None, name='exe_phon')
thisExp.addLoop(exe_phon)  # add the loop to the experiment
thisExe_phon = exe_phon.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisExe_phon.rgb)
if thisExe_phon != None:
    for paramName in thisExe_phon.keys():
        exec(paramName + '= thisExe_phon.' + paramName)

for thisExe_phon in exe_phon:
    currentLoop = exe_phon
    # abbreviate parameter names if possible (e.g. rgb = thisExe_phon.rgb)
    if thisExe_phon != None:
        for paramName in thisExe_phon.keys():
            exec(paramName + '= thisExe_phon.' + paramName)
    
    #------Prepare to start Routine "evaluation"-------
    t = 0
    evaluationClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    img_complet.setImage(complet)
    touche_rep = event.BuilderKeyResponse()  # create an object of type KeyResponse
    touche_rep.status = NOT_STARTED
    txt_elision.setText(elision)
    # keep track of which components have finished
    evaluationComponents = []
    evaluationComponents.append(img_complet)
    evaluationComponents.append(touche_rep)
    evaluationComponents.append(txt_elision)
    evaluationComponents.append(minus)
    evaluationComponents.append(equal)
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "evaluation"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = evaluationClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *img_complet* updates
        if t >= 0.0 and img_complet.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_complet.tStart = t  # underestimates by a little under one frame
            img_complet.frameNStart = frameN  # exact frame index
            img_complet.setAutoDraw(True)
        
        # *touche_rep* updates
        if t >= 0.0 and touche_rep.status == NOT_STARTED:
            # keep track of start time/frame for later
            touche_rep.tStart = t  # underestimates by a little under one frame
            touche_rep.frameNStart = frameN  # exact frame index
            touche_rep.status = STARTED
            # keyboard checking is just starting
            touche_rep.clock.reset()  # now t=0
            event.clearEvents(eventType='keyboard')
        if touche_rep.status == STARTED:
            theseKeys = event.getKeys(keyList=['o', 'n', 'a'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                touche_rep.keys = theseKeys[-1]  # just the last key pressed
                touche_rep.rt = touche_rep.clock.getTime()
                # was this 'correct'?
                if (touche_rep.keys == str("'o'")) or (touche_rep.keys == "'o'"):
                    touche_rep.corr = 1
                else:
                    touche_rep.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *txt_elision* updates
        if t >= 0.0 and txt_elision.status == NOT_STARTED:
            # keep track of start time/frame for later
            txt_elision.tStart = t  # underestimates by a little under one frame
            txt_elision.frameNStart = frameN  # exact frame index
            txt_elision.setAutoDraw(True)
        
        # *minus* updates
        if t >= 0.0 and minus.status == NOT_STARTED:
            # keep track of start time/frame for later
            minus.tStart = t  # underestimates by a little under one frame
            minus.frameNStart = frameN  # exact frame index
            minus.setAutoDraw(True)
        
        # *equal* updates
        if t >= 0.0 and equal.status == NOT_STARTED:
            # keep track of start time/frame for later
            equal.tStart = t  # underestimates by a little under one frame
            equal.frameNStart = frameN  # exact frame index
            equal.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in evaluationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "evaluation"-------
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if touche_rep.keys in ['', [], None]:  # No response was made
       touche_rep.keys=None
       # was no response the correct answer?!
       if str("'o'").lower() == 'none': touche_rep.corr = 1  # correct non-response
       else: touche_rep.corr = 0  # failed to respond (incorrectly)
    # store data for exe_phon (TrialHandler)
    exe_phon.addData('touche_rep.keys',touche_rep.keys)
    exe_phon.addData('touche_rep.corr', touche_rep.corr)
    if touche_rep.keys != None:  # we had a response
        exe_phon.addData('touche_rep.rt', touche_rep.rt)
    # the Routine "evaluation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
# completed 1 repeats of 'exe_phon'


#------Prepare to start Routine "annonce_exercice"-------
t = 0
annonce_exerciceClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_6 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_6.status = NOT_STARTED
# keep track of which components have finished
annonce_exerciceComponents = []
annonce_exerciceComponents.append(txt_exer)
annonce_exerciceComponents.append(key_resp_6)
for thisComponent in annonce_exerciceComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "annonce_exercice"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = annonce_exerciceClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_exer* updates
    if t >= 0.0 and txt_exer.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_exer.tStart = t  # underestimates by a little under one frame
        txt_exer.frameNStart = frameN  # exact frame index
        txt_exer.setAutoDraw(True)
    
    # *key_resp_6* updates
    if t >= 0.0 and key_resp_6.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_6.tStart = t  # underestimates by a little under one frame
        key_resp_6.frameNStart = frameN  # exact frame index
        key_resp_6.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_resp_6.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in annonce_exerciceComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "annonce_exercice"-------
for thisComponent in annonce_exerciceComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "annonce_exercice" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
elisions_phon = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=u'/Users/laurencemourier/Google Drive/test_PsychoPy/ex2/elision_phonemique.psyexp',
    trialList=data.importConditions('elision_phonemique.xlsx', selection='5:20'),
    seed=None, name='elisions_phon')
thisExp.addLoop(elisions_phon)  # add the loop to the experiment
thisElisions_phon = elisions_phon.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisElisions_phon.rgb)
if thisElisions_phon != None:
    for paramName in thisElisions_phon.keys():
        exec(paramName + '= thisElisions_phon.' + paramName)

for thisElisions_phon in elisions_phon:
    currentLoop = elisions_phon
    # abbreviate parameter names if possible (e.g. rgb = thisElisions_phon.rgb)
    if thisElisions_phon != None:
        for paramName in thisElisions_phon.keys():
            exec(paramName + '= thisElisions_phon.' + paramName)
    
    #------Prepare to start Routine "evaluation"-------
    t = 0
    evaluationClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    img_complet.setImage(complet)
    touche_rep = event.BuilderKeyResponse()  # create an object of type KeyResponse
    touche_rep.status = NOT_STARTED
    txt_elision.setText(elision)
    # keep track of which components have finished
    evaluationComponents = []
    evaluationComponents.append(img_complet)
    evaluationComponents.append(touche_rep)
    evaluationComponents.append(txt_elision)
    evaluationComponents.append(minus)
    evaluationComponents.append(equal)
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "evaluation"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = evaluationClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *img_complet* updates
        if t >= 0.0 and img_complet.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_complet.tStart = t  # underestimates by a little under one frame
            img_complet.frameNStart = frameN  # exact frame index
            img_complet.setAutoDraw(True)
        
        # *touche_rep* updates
        if t >= 0.0 and touche_rep.status == NOT_STARTED:
            # keep track of start time/frame for later
            touche_rep.tStart = t  # underestimates by a little under one frame
            touche_rep.frameNStart = frameN  # exact frame index
            touche_rep.status = STARTED
            # keyboard checking is just starting
            touche_rep.clock.reset()  # now t=0
            event.clearEvents(eventType='keyboard')
        if touche_rep.status == STARTED:
            theseKeys = event.getKeys(keyList=['o', 'n', 'a'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                touche_rep.keys = theseKeys[-1]  # just the last key pressed
                touche_rep.rt = touche_rep.clock.getTime()
                # was this 'correct'?
                if (touche_rep.keys == str("'o'")) or (touche_rep.keys == "'o'"):
                    touche_rep.corr = 1
                else:
                    touche_rep.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *txt_elision* updates
        if t >= 0.0 and txt_elision.status == NOT_STARTED:
            # keep track of start time/frame for later
            txt_elision.tStart = t  # underestimates by a little under one frame
            txt_elision.frameNStart = frameN  # exact frame index
            txt_elision.setAutoDraw(True)
        
        # *minus* updates
        if t >= 0.0 and minus.status == NOT_STARTED:
            # keep track of start time/frame for later
            minus.tStart = t  # underestimates by a little under one frame
            minus.frameNStart = frameN  # exact frame index
            minus.setAutoDraw(True)
        
        # *equal* updates
        if t >= 0.0 and equal.status == NOT_STARTED:
            # keep track of start time/frame for later
            equal.tStart = t  # underestimates by a little under one frame
            equal.frameNStart = frameN  # exact frame index
            equal.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in evaluationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "evaluation"-------
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if touche_rep.keys in ['', [], None]:  # No response was made
       touche_rep.keys=None
       # was no response the correct answer?!
       if str("'o'").lower() == 'none': touche_rep.corr = 1  # correct non-response
       else: touche_rep.corr = 0  # failed to respond (incorrectly)
    # store data for elisions_phon (TrialHandler)
    elisions_phon.addData('touche_rep.keys',touche_rep.keys)
    elisions_phon.addData('touche_rep.corr', touche_rep.corr)
    if touche_rep.keys != None:  # we had a response
        elisions_phon.addData('touche_rep.rt', touche_rep.rt)
    # the Routine "evaluation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'elisions_phon'

# get names of stimulus parameters
if elisions_phon.trialList in ([], [None], None):  params = []
else:  params = elisions_phon.trialList[0].keys()
# save data for this loop
elisions_phon.saveAsExcel(filename + '.xlsx', sheetName='elisions_phon',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])

#------Prepare to start Routine "fin"-------
t = 0
finClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_7 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_7.status = NOT_STARTED
# keep track of which components have finished
finComponents = []
finComponents.append(txt_fin)
finComponents.append(key_resp_7)
for thisComponent in finComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "fin"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = finClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_fin* updates
    if t >= 0.0 and txt_fin.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_fin.tStart = t  # underestimates by a little under one frame
        txt_fin.frameNStart = frameN  # exact frame index
        txt_fin.setAutoDraw(True)
    
    # *key_resp_7* updates
    if t >= 0.0 and key_resp_7.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_7.tStart = t  # underestimates by a little under one frame
        key_resp_7.frameNStart = frameN  # exact frame index
        key_resp_7.status = STARTED
        # keyboard checking is just starting
        key_resp_7.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_7.status == STARTED:
        theseKeys = event.getKeys()
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_7.keys = theseKeys[-1]  # just the last key pressed
            key_resp_7.rt = key_resp_7.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in finComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "fin"-------
for thisComponent in finComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_7.keys in ['', [], None]:  # No response was made
   key_resp_7.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_7.keys',key_resp_7.keys)
if key_resp_7.keys != None:  # we had a response
    thisExp.addData('key_resp_7.rt', key_resp_7.rt)
thisExp.nextEntry()
# the Routine "fin" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()
win.close()
core.quit()
