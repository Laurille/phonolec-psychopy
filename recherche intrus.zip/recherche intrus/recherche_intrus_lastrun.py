#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.82.01), Sam  7 mai 18:05:28 2016
If you publish work using this script please cite the relevant PsychoPy publications
  Peirce, JW (2007) PsychoPy - Psychophysics software in Python. Journal of Neuroscience Methods, 162(1-2), 8-13.
  Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy. Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import division  # so that 1/3=0.333 instead of 1/3=0
from psychopy import visual, core, data, event, logging, sound, gui
from psychopy.constants import *  # things like STARTED, FINISHED
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import sin, cos, tan, log, log10, pi, average, sqrt, std, deg2rad, rad2deg, linspace, asarray
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'recherche_intrus2'  # from the Builder filename that created this script
expInfo = {u'age': u'', u'session': u'001', u'patient': u'', u'evaluateur': u''}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False: core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + 'data/%s_%s_%s_%s' %(expInfo['evaluateur'], expInfo['patient'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=u'/Users/laurencemourier/Google Drive/test_PsychoPy/ex3/recherche_intrus.psyexp',
    savePickle=True, saveWideText=False,
    dataFileName=filename)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(size=(1440, 900), fullscr=True, screen=0, allowGUI=True, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True,
    )
# store frame rate of monitor if we can measure it successfully
expInfo['frameRate']=win.getActualFrameRate()
if expInfo['frameRate']!=None:
    frameDur = 1.0/round(expInfo['frameRate'])
else:
    frameDur = 1.0/60.0 # couldn't get a reliable measure so guess

# Initialize components for Routine "titre"
titreClock = core.Clock()
txt_titre = visual.TextStim(win=win, ori=0, name='txt_titre',
    text='EXERCICE 3',    font='Arial',
    pos=[0, 0], height=0.25, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "consigne"
consigneClock = core.Clock()
txt_cons1 = visual.TextStim(win=win, ori=0, name='txt_cons1',
    text=u"Vous allez voir quatre images, qui repr\xe9sentent chacune un mot.\n\nCherchez l'intrus.\n\nC'est le mot qui ne commence pas, ou ne se termine pas comme les trois autres.",    font='Arial',
    pos=[0, 0], height=0.125, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "annonce_ex"
annonce_exClock = core.Clock()
txt_ann_ex = visual.TextStim(win=win, ori=0, name='txt_ann_ex',
    text=u"Vous allez d'abord vous entrainer.\n\nEtes-vous pr\xeat ?",    font='Arial',
    pos=[0, 0], height=0.125, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "evaluation"
evaluationClock = core.Clock()
img_hg = visual.ImageStim(win=win, name='img_hg',
    image='sin', mask=None,
    ori=0, pos=[-0.4, 0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
img_hd = visual.ImageStim(win=win, name='img_hd',
    image='sin', mask=None,
    ori=0, pos=[0.4, 0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
img_bg = visual.ImageStim(win=win, name='img_bg',
    image='sin', mask=None,
    ori=0, pos=[-0.4, -0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
img_bd = visual.ImageStim(win=win, name='img_bd',
    image='sin', mask=None,
    ori=0, pos=[0.4, -0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "solution"
solutionClock = core.Clock()
solbd = visual.ImageStim(win=win, name='solbd',
    image='sin', mask=None,
    ori=0, pos=[0.3, -0.2], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1.0,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
solbg = visual.ImageStim(win=win, name='solbg',
    image='sin', mask=None,
    ori=0, pos=[-0.3, -0.2], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1.0,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
solhd = visual.ImageStim(win=win, name='solhd',
    image='sin', mask=None,
    ori=0, pos=[0.3, 0.4], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1.0,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
solhg = visual.ImageStim(win=win, name='solhg',
    image='sin', mask=None,
    ori=0, pos=[-0.3, 0.4], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1.0,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
txt_sol = visual.TextStim(win=win, ori=0, name='txt_sol',
    text='Solution :',    font='Arial',
    pos=[0, 0.9], height=0.125, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=-4.0)
txt_expl = visual.TextStim(win=win, ori=0, name='txt_expl',
    text='default text',    font='Arial',
    pos=[0, -0.75], height=0.12, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=-6.0)

# Initialize components for Routine "evaluation"
evaluationClock = core.Clock()
img_hg = visual.ImageStim(win=win, name='img_hg',
    image='sin', mask=None,
    ori=0, pos=[-0.4, 0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
img_hd = visual.ImageStim(win=win, name='img_hd',
    image='sin', mask=None,
    ori=0, pos=[0.4, 0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
img_bg = visual.ImageStim(win=win, name='img_bg',
    image='sin', mask=None,
    ori=0, pos=[-0.4, -0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
img_bd = visual.ImageStim(win=win, name='img_bd',
    image='sin', mask=None,
    ori=0, pos=[0.4, -0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "annonce_exercice"
annonce_exerciceClock = core.Clock()
txt_exer = visual.TextStim(win=win, ori=0, name='txt_exer',
    text=u"L'exercice va commencer.\n\nDonnez votre r\xe9ponse \xe0 voix haute, le plus rapidement possible.\n\nEtes-vous pr\xeat ?",    font='Arial',
    pos=[0, 0], height=0.125, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "evaluation"
evaluationClock = core.Clock()
img_hg = visual.ImageStim(win=win, name='img_hg',
    image='sin', mask=None,
    ori=0, pos=[-0.4, 0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
img_hd = visual.ImageStim(win=win, name='img_hd',
    image='sin', mask=None,
    ori=0, pos=[0.4, 0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
img_bg = visual.ImageStim(win=win, name='img_bg',
    image='sin', mask=None,
    ori=0, pos=[-0.4, -0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
img_bd = visual.ImageStim(win=win, name='img_bd',
    image='sin', mask=None,
    ori=0, pos=[0.4, -0.5], size=[0.75, 0.75],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "fin"
finClock = core.Clock()
txt_fin = visual.TextStim(win=win, ori=0, name='txt_fin',
    text=u'Merci, ce troisi\xe8me exercice est termin\xe9.',    font='Arial',
    pos=[0, 0], height=0.2, wrapWidth=1.5,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

#------Prepare to start Routine "titre"-------
t = 0
titreClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_5 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_5.status = NOT_STARTED
# keep track of which components have finished
titreComponents = []
titreComponents.append(txt_titre)
titreComponents.append(key_resp_5)
for thisComponent in titreComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "titre"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = titreClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_titre* updates
    if t >= 0.0 and txt_titre.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_titre.tStart = t  # underestimates by a little under one frame
        txt_titre.frameNStart = frameN  # exact frame index
        txt_titre.setAutoDraw(True)
    
    # *key_resp_5* updates
    if t >= 0.0 and key_resp_5.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_5.tStart = t  # underestimates by a little under one frame
        key_resp_5.frameNStart = frameN  # exact frame index
        key_resp_5.status = STARTED
        # keyboard checking is just starting
        key_resp_5.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_5.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_5.keys = theseKeys[-1]  # just the last key pressed
            key_resp_5.rt = key_resp_5.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in titreComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "titre"-------
for thisComponent in titreComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_5.keys in ['', [], None]:  # No response was made
   key_resp_5.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_5.keys',key_resp_5.keys)
if key_resp_5.keys != None:  # we had a response
    thisExp.addData('key_resp_5.rt', key_resp_5.rt)
thisExp.nextEntry()
# the Routine "titre" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

#------Prepare to start Routine "consigne"-------
t = 0
consigneClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_2 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_2.status = NOT_STARTED
# keep track of which components have finished
consigneComponents = []
consigneComponents.append(txt_cons1)
consigneComponents.append(key_resp_2)
for thisComponent in consigneComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "consigne"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = consigneClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_cons1* updates
    if t >= 0.0 and txt_cons1.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_cons1.tStart = t  # underestimates by a little under one frame
        txt_cons1.frameNStart = frameN  # exact frame index
        txt_cons1.setAutoDraw(True)
    
    # *key_resp_2* updates
    if t >= 0.0 and key_resp_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_2.tStart = t  # underestimates by a little under one frame
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_resp_2.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in consigneComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "consigne"-------
for thisComponent in consigneComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "consigne" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

#------Prepare to start Routine "annonce_ex"-------
t = 0
annonce_exClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_8 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_8.status = NOT_STARTED
# keep track of which components have finished
annonce_exComponents = []
annonce_exComponents.append(txt_ann_ex)
annonce_exComponents.append(key_resp_8)
for thisComponent in annonce_exComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "annonce_ex"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = annonce_exClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_ann_ex* updates
    if t >= 0.0 and txt_ann_ex.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_ann_ex.tStart = t  # underestimates by a little under one frame
        txt_ann_ex.frameNStart = frameN  # exact frame index
        txt_ann_ex.setAutoDraw(True)
    
    # *key_resp_8* updates
    if t >= 0.0 and key_resp_8.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_8.tStart = t  # underestimates by a little under one frame
        key_resp_8.frameNStart = frameN  # exact frame index
        key_resp_8.status = STARTED
        # keyboard checking is just starting
        key_resp_8.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_8.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_8.keys = theseKeys[-1]  # just the last key pressed
            key_resp_8.rt = key_resp_8.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in annonce_exComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "annonce_ex"-------
for thisComponent in annonce_exComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_8.keys in ['', [], None]:  # No response was made
   key_resp_8.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_8.keys',key_resp_8.keys)
if key_resp_8.keys != None:  # we had a response
    thisExp.addData('key_resp_8.rt', key_resp_8.rt)
thisExp.nextEntry()
# the Routine "annonce_ex" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
exemples_intrus = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=u'/Users/laurencemourier/Google Drive/test_PsychoPy/ex3/recherche_intrus.psyexp',
    trialList=data.importConditions('recherche_intrus.xlsx', selection='0,1,2'),
    seed=None, name='exemples_intrus')
thisExp.addLoop(exemples_intrus)  # add the loop to the experiment
thisExemples_intru = exemples_intrus.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisExemples_intru.rgb)
if thisExemples_intru != None:
    for paramName in thisExemples_intru.keys():
        exec(paramName + '= thisExemples_intru.' + paramName)

for thisExemples_intru in exemples_intrus:
    currentLoop = exemples_intrus
    # abbreviate parameter names if possible (e.g. rgb = thisExemples_intru.rgb)
    if thisExemples_intru != None:
        for paramName in thisExemples_intru.keys():
            exec(paramName + '= thisExemples_intru.' + paramName)
    
    #------Prepare to start Routine "evaluation"-------
    t = 0
    evaluationClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    touche_rep = event.BuilderKeyResponse()  # create an object of type KeyResponse
    touche_rep.status = NOT_STARTED
    img_hg.setImage(hg)
    img_hd.setImage(hd)
    img_bg.setImage(bg)
    img_bd.setImage(bd)
    # keep track of which components have finished
    evaluationComponents = []
    evaluationComponents.append(touche_rep)
    evaluationComponents.append(img_hg)
    evaluationComponents.append(img_hd)
    evaluationComponents.append(img_bg)
    evaluationComponents.append(img_bd)
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "evaluation"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = evaluationClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *touche_rep* updates
        if t >= 0.0 and touche_rep.status == NOT_STARTED:
            # keep track of start time/frame for later
            touche_rep.tStart = t  # underestimates by a little under one frame
            touche_rep.frameNStart = frameN  # exact frame index
            touche_rep.status = STARTED
            # keyboard checking is just starting
            touche_rep.clock.reset()  # now t=0
            event.clearEvents(eventType='keyboard')
        if touche_rep.status == STARTED:
            theseKeys = event.getKeys(keyList=['o', 'n', 'a'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                touche_rep.keys = theseKeys[-1]  # just the last key pressed
                touche_rep.rt = touche_rep.clock.getTime()
                # was this 'correct'?
                if (touche_rep.keys == str("'o'")) or (touche_rep.keys == "'o'"):
                    touche_rep.corr = 1
                else:
                    touche_rep.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *img_hg* updates
        if t >= 0.0 and img_hg.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_hg.tStart = t  # underestimates by a little under one frame
            img_hg.frameNStart = frameN  # exact frame index
            img_hg.setAutoDraw(True)
        
        # *img_hd* updates
        if t >= 0.0 and img_hd.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_hd.tStart = t  # underestimates by a little under one frame
            img_hd.frameNStart = frameN  # exact frame index
            img_hd.setAutoDraw(True)
        
        # *img_bg* updates
        if t >= 0.0 and img_bg.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_bg.tStart = t  # underestimates by a little under one frame
            img_bg.frameNStart = frameN  # exact frame index
            img_bg.setAutoDraw(True)
        
        # *img_bd* updates
        if t >= 0.0 and img_bd.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_bd.tStart = t  # underestimates by a little under one frame
            img_bd.frameNStart = frameN  # exact frame index
            img_bd.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in evaluationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "evaluation"-------
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if touche_rep.keys in ['', [], None]:  # No response was made
       touche_rep.keys=None
       # was no response the correct answer?!
       if str("'o'").lower() == 'none': touche_rep.corr = 1  # correct non-response
       else: touche_rep.corr = 0  # failed to respond (incorrectly)
    # store data for exemples_intrus (TrialHandler)
    exemples_intrus.addData('touche_rep.keys',touche_rep.keys)
    exemples_intrus.addData('touche_rep.corr', touche_rep.corr)
    if touche_rep.keys != None:  # we had a response
        exemples_intrus.addData('touche_rep.rt', touche_rep.rt)
    # the Routine "evaluation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    #------Prepare to start Routine "solution"-------
    t = 0
    solutionClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    solbd.setOpacity(bd_sol/2 - 0.5)
    solbd.setImage(bd)
    solbd.setSize([0.25*bd_sol, 0.25*bd_sol])
    solbg.setOpacity(bg_sol/2 - 0.5)
    solbg.setImage(bg)
    solbg.setSize([0.25*bg_sol, 0.25*bg_sol])
    solhd.setOpacity(hd_sol/2 - 0.5)
    solhd.setImage(hd)
    solhd.setSize([0.25*hd_sol, 0.25*hd_sol])
    solhg.setOpacity(hg_sol/2 - 0.5)
    solhg.setImage(hg)
    solhg.setSize([0.25*hg_sol, 0.25*hg_sol])
    key_resp_3 = event.BuilderKeyResponse()  # create an object of type KeyResponse
    key_resp_3.status = NOT_STARTED
    txt_expl.setText(explication)
    # keep track of which components have finished
    solutionComponents = []
    solutionComponents.append(solbd)
    solutionComponents.append(solbg)
    solutionComponents.append(solhd)
    solutionComponents.append(solhg)
    solutionComponents.append(txt_sol)
    solutionComponents.append(key_resp_3)
    solutionComponents.append(txt_expl)
    for thisComponent in solutionComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "solution"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = solutionClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *solbd* updates
        if t >= 0.0 and solbd.status == NOT_STARTED:
            # keep track of start time/frame for later
            solbd.tStart = t  # underestimates by a little under one frame
            solbd.frameNStart = frameN  # exact frame index
            solbd.setAutoDraw(True)
        
        # *solbg* updates
        if t >= 0.0 and solbg.status == NOT_STARTED:
            # keep track of start time/frame for later
            solbg.tStart = t  # underestimates by a little under one frame
            solbg.frameNStart = frameN  # exact frame index
            solbg.setAutoDraw(True)
        
        # *solhd* updates
        if t >= 0.0 and solhd.status == NOT_STARTED:
            # keep track of start time/frame for later
            solhd.tStart = t  # underestimates by a little under one frame
            solhd.frameNStart = frameN  # exact frame index
            solhd.setAutoDraw(True)
        
        # *solhg* updates
        if t >= 0.0 and solhg.status == NOT_STARTED:
            # keep track of start time/frame for later
            solhg.tStart = t  # underestimates by a little under one frame
            solhg.frameNStart = frameN  # exact frame index
            solhg.setAutoDraw(True)
        
        # *txt_sol* updates
        if t >= 0.0 and txt_sol.status == NOT_STARTED:
            # keep track of start time/frame for later
            txt_sol.tStart = t  # underestimates by a little under one frame
            txt_sol.frameNStart = frameN  # exact frame index
            txt_sol.setAutoDraw(True)
        
        # *key_resp_3* updates
        if t >= 0.0 and key_resp_3.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_3.tStart = t  # underestimates by a little under one frame
            key_resp_3.frameNStart = frameN  # exact frame index
            key_resp_3.status = STARTED
            # keyboard checking is just starting
            event.clearEvents(eventType='keyboard')
        if key_resp_3.status == STARTED:
            theseKeys = event.getKeys(keyList=['right'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                # a response ends the routine
                continueRoutine = False
        
        # *txt_expl* updates
        if t >= 0.0 and txt_expl.status == NOT_STARTED:
            # keep track of start time/frame for later
            txt_expl.tStart = t  # underestimates by a little under one frame
            txt_expl.frameNStart = frameN  # exact frame index
            txt_expl.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in solutionComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "solution"-------
    for thisComponent in solutionComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "solution" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
# completed 1 repeats of 'exemples_intrus'


# set up handler to look after randomisation of conditions etc
exercices = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=u'/Users/laurencemourier/Google Drive/test_PsychoPy/ex3/recherche_intrus.psyexp',
    trialList=data.importConditions('recherche_intrus.xlsx', selection='3,4'),
    seed=None, name='exercices')
thisExp.addLoop(exercices)  # add the loop to the experiment
thisExercice = exercices.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisExercice.rgb)
if thisExercice != None:
    for paramName in thisExercice.keys():
        exec(paramName + '= thisExercice.' + paramName)

for thisExercice in exercices:
    currentLoop = exercices
    # abbreviate parameter names if possible (e.g. rgb = thisExercice.rgb)
    if thisExercice != None:
        for paramName in thisExercice.keys():
            exec(paramName + '= thisExercice.' + paramName)
    
    #------Prepare to start Routine "evaluation"-------
    t = 0
    evaluationClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    touche_rep = event.BuilderKeyResponse()  # create an object of type KeyResponse
    touche_rep.status = NOT_STARTED
    img_hg.setImage(hg)
    img_hd.setImage(hd)
    img_bg.setImage(bg)
    img_bd.setImage(bd)
    # keep track of which components have finished
    evaluationComponents = []
    evaluationComponents.append(touche_rep)
    evaluationComponents.append(img_hg)
    evaluationComponents.append(img_hd)
    evaluationComponents.append(img_bg)
    evaluationComponents.append(img_bd)
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "evaluation"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = evaluationClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *touche_rep* updates
        if t >= 0.0 and touche_rep.status == NOT_STARTED:
            # keep track of start time/frame for later
            touche_rep.tStart = t  # underestimates by a little under one frame
            touche_rep.frameNStart = frameN  # exact frame index
            touche_rep.status = STARTED
            # keyboard checking is just starting
            touche_rep.clock.reset()  # now t=0
            event.clearEvents(eventType='keyboard')
        if touche_rep.status == STARTED:
            theseKeys = event.getKeys(keyList=['o', 'n', 'a'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                touche_rep.keys = theseKeys[-1]  # just the last key pressed
                touche_rep.rt = touche_rep.clock.getTime()
                # was this 'correct'?
                if (touche_rep.keys == str("'o'")) or (touche_rep.keys == "'o'"):
                    touche_rep.corr = 1
                else:
                    touche_rep.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *img_hg* updates
        if t >= 0.0 and img_hg.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_hg.tStart = t  # underestimates by a little under one frame
            img_hg.frameNStart = frameN  # exact frame index
            img_hg.setAutoDraw(True)
        
        # *img_hd* updates
        if t >= 0.0 and img_hd.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_hd.tStart = t  # underestimates by a little under one frame
            img_hd.frameNStart = frameN  # exact frame index
            img_hd.setAutoDraw(True)
        
        # *img_bg* updates
        if t >= 0.0 and img_bg.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_bg.tStart = t  # underestimates by a little under one frame
            img_bg.frameNStart = frameN  # exact frame index
            img_bg.setAutoDraw(True)
        
        # *img_bd* updates
        if t >= 0.0 and img_bd.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_bd.tStart = t  # underestimates by a little under one frame
            img_bd.frameNStart = frameN  # exact frame index
            img_bd.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in evaluationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "evaluation"-------
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if touche_rep.keys in ['', [], None]:  # No response was made
       touche_rep.keys=None
       # was no response the correct answer?!
       if str("'o'").lower() == 'none': touche_rep.corr = 1  # correct non-response
       else: touche_rep.corr = 0  # failed to respond (incorrectly)
    # store data for exercices (TrialHandler)
    exercices.addData('touche_rep.keys',touche_rep.keys)
    exercices.addData('touche_rep.corr', touche_rep.corr)
    if touche_rep.keys != None:  # we had a response
        exercices.addData('touche_rep.rt', touche_rep.rt)
    # the Routine "evaluation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
# completed 1 repeats of 'exercices'


#------Prepare to start Routine "annonce_exercice"-------
t = 0
annonce_exerciceClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_6 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_6.status = NOT_STARTED
# keep track of which components have finished
annonce_exerciceComponents = []
annonce_exerciceComponents.append(txt_exer)
annonce_exerciceComponents.append(key_resp_6)
for thisComponent in annonce_exerciceComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "annonce_exercice"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = annonce_exerciceClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_exer* updates
    if t >= 0.0 and txt_exer.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_exer.tStart = t  # underestimates by a little under one frame
        txt_exer.frameNStart = frameN  # exact frame index
        txt_exer.setAutoDraw(True)
    
    # *key_resp_6* updates
    if t >= 0.0 and key_resp_6.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_6.tStart = t  # underestimates by a little under one frame
        key_resp_6.frameNStart = frameN  # exact frame index
        key_resp_6.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_resp_6.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in annonce_exerciceComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "annonce_exercice"-------
for thisComponent in annonce_exerciceComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "annonce_exercice" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
recherches = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=u'/Users/laurencemourier/Google Drive/test_PsychoPy/ex3/recherche_intrus.psyexp',
    trialList=data.importConditions('recherche_intrus.xlsx', selection='5:25'),
    seed=None, name='recherches')
thisExp.addLoop(recherches)  # add the loop to the experiment
thisRecherche = recherches.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisRecherche.rgb)
if thisRecherche != None:
    for paramName in thisRecherche.keys():
        exec(paramName + '= thisRecherche.' + paramName)

for thisRecherche in recherches:
    currentLoop = recherches
    # abbreviate parameter names if possible (e.g. rgb = thisRecherche.rgb)
    if thisRecherche != None:
        for paramName in thisRecherche.keys():
            exec(paramName + '= thisRecherche.' + paramName)
    
    #------Prepare to start Routine "evaluation"-------
    t = 0
    evaluationClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    touche_rep = event.BuilderKeyResponse()  # create an object of type KeyResponse
    touche_rep.status = NOT_STARTED
    img_hg.setImage(hg)
    img_hd.setImage(hd)
    img_bg.setImage(bg)
    img_bd.setImage(bd)
    # keep track of which components have finished
    evaluationComponents = []
    evaluationComponents.append(touche_rep)
    evaluationComponents.append(img_hg)
    evaluationComponents.append(img_hd)
    evaluationComponents.append(img_bg)
    evaluationComponents.append(img_bd)
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "evaluation"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = evaluationClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *touche_rep* updates
        if t >= 0.0 and touche_rep.status == NOT_STARTED:
            # keep track of start time/frame for later
            touche_rep.tStart = t  # underestimates by a little under one frame
            touche_rep.frameNStart = frameN  # exact frame index
            touche_rep.status = STARTED
            # keyboard checking is just starting
            touche_rep.clock.reset()  # now t=0
            event.clearEvents(eventType='keyboard')
        if touche_rep.status == STARTED:
            theseKeys = event.getKeys(keyList=['o', 'n', 'a'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                touche_rep.keys = theseKeys[-1]  # just the last key pressed
                touche_rep.rt = touche_rep.clock.getTime()
                # was this 'correct'?
                if (touche_rep.keys == str("'o'")) or (touche_rep.keys == "'o'"):
                    touche_rep.corr = 1
                else:
                    touche_rep.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *img_hg* updates
        if t >= 0.0 and img_hg.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_hg.tStart = t  # underestimates by a little under one frame
            img_hg.frameNStart = frameN  # exact frame index
            img_hg.setAutoDraw(True)
        
        # *img_hd* updates
        if t >= 0.0 and img_hd.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_hd.tStart = t  # underestimates by a little under one frame
            img_hd.frameNStart = frameN  # exact frame index
            img_hd.setAutoDraw(True)
        
        # *img_bg* updates
        if t >= 0.0 and img_bg.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_bg.tStart = t  # underestimates by a little under one frame
            img_bg.frameNStart = frameN  # exact frame index
            img_bg.setAutoDraw(True)
        
        # *img_bd* updates
        if t >= 0.0 and img_bd.status == NOT_STARTED:
            # keep track of start time/frame for later
            img_bd.tStart = t  # underestimates by a little under one frame
            img_bd.frameNStart = frameN  # exact frame index
            img_bd.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in evaluationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "evaluation"-------
    for thisComponent in evaluationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if touche_rep.keys in ['', [], None]:  # No response was made
       touche_rep.keys=None
       # was no response the correct answer?!
       if str("'o'").lower() == 'none': touche_rep.corr = 1  # correct non-response
       else: touche_rep.corr = 0  # failed to respond (incorrectly)
    # store data for recherches (TrialHandler)
    recherches.addData('touche_rep.keys',touche_rep.keys)
    recherches.addData('touche_rep.corr', touche_rep.corr)
    if touche_rep.keys != None:  # we had a response
        recherches.addData('touche_rep.rt', touche_rep.rt)
    # the Routine "evaluation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'recherches'

# get names of stimulus parameters
if recherches.trialList in ([], [None], None):  params = []
else:  params = recherches.trialList[0].keys()
# save data for this loop
recherches.saveAsExcel(filename + '.xlsx', sheetName='recherches',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])

#------Prepare to start Routine "fin"-------
t = 0
finClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_7 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_7.status = NOT_STARTED
# keep track of which components have finished
finComponents = []
finComponents.append(txt_fin)
finComponents.append(key_resp_7)
for thisComponent in finComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "fin"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = finClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_fin* updates
    if t >= 0.0 and txt_fin.status == NOT_STARTED:
        # keep track of start time/frame for later
        txt_fin.tStart = t  # underestimates by a little under one frame
        txt_fin.frameNStart = frameN  # exact frame index
        txt_fin.setAutoDraw(True)
    
    # *key_resp_7* updates
    if t >= 0.0 and key_resp_7.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_7.tStart = t  # underestimates by a little under one frame
        key_resp_7.frameNStart = frameN  # exact frame index
        key_resp_7.status = STARTED
        # keyboard checking is just starting
        key_resp_7.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_7.status == STARTED:
        theseKeys = event.getKeys()
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_7.keys = theseKeys[-1]  # just the last key pressed
            key_resp_7.rt = key_resp_7.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in finComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "fin"-------
for thisComponent in finComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_7.keys in ['', [], None]:  # No response was made
   key_resp_7.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_7.keys',key_resp_7.keys)
if key_resp_7.keys != None:  # we had a response
    thisExp.addData('key_resp_7.rt', key_resp_7.rt)
thisExp.nextEntry()
# the Routine "fin" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()
win.close()
core.quit()
